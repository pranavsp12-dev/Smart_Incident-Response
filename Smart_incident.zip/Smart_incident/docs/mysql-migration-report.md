# MySQL migration report

## Source and export scope

- Source PostgreSQL database: `smart_incident` (read-only export).
- Public base tables inspected: 13.
- Full source rows were queried from every public base table; row values are embedded in `mysql_smart_incident.sql` as explicit multi-row INSERT statements.
- The existing admin row was verified by `(user_id = 53, email = admin@smart.com)` without printing its password hash.
- Demo incidents found in the source: 20.
- MongoDB incident events are outside this PostgreSQL export and were not copied.

## Table mapping and source row counts

| PostgreSQL table | MySQL table | PostgreSQL rows | MySQL rows represented |
|---|---|---:|---|
| `app_user` | `app_user` | 14 | Not executed; SQL contains 14 explicit source rows |
| `environment` | `environment` | 5 | Not executed; SQL contains 5 explicit source rows |
| `escalation_level` | `escalation_level` | 8 | Not executed; SQL contains 8 explicit source rows |
| `escalation_policy` | `escalation_policy` | 4 | Not executed; SQL contains 4 explicit source rows |
| `incident` | `incident` | 21 | Not executed; SQL contains 21 explicit source rows |
| `incident_assignment` | `incident_assignment` | 20 | Not executed; SQL contains 20 explicit source rows |
| `incident_tag` | `incident_tag` | 38 | Not executed; SQL contains 38 explicit source rows |
| `incident_update` | `incident_update` | 40 | Not executed; SQL contains 40 explicit source rows |
| `on_call_assignment` | `on_call_assignment` | 8 | Not executed; SQL contains 8 explicit source rows |
| `on_call_schedule` | `on_call_schedule` | 4 | Not executed; SQL contains 4 explicit source rows |
| `service` | `service` | 9 | Not executed; SQL contains 9 explicit source rows |
| `tag` | `tag` | 8 | Not executed; SQL contains 8 explicit source rows |
| `team` | `team` | 4 | Not executed; SQL contains 4 explicit source rows |

The MySQL server service is installed and running, but a read-only TCP query was not permitted with passwordless credentials. No MySQL database was created and the target database existence could not be queried. The export script uses bare `CREATE DATABASE`, so execution will fail rather than overwrite if `smart_incident_mysql` already exists.

## Schema objects

- Primary-key constraints: 13.
- Unique constraints: 6.
- Foreign-key constraints: 17.
- Check constraints: 11.
- Non-constraint secondary indexes: 22.
- PostgreSQL sequences: 12; translated to `AUTO_INCREMENT` and explicitly advanced past both the source next value and imported maximum ID.
- Views: 0; materialized views: 0; user triggers: 0; public routines: 0.
- No views, materialized views, triggers, or public routines were present in the inspected source.
- Additional catalog checks found 0 row-level security policies, 0 event triggers, 0 partitioned tables, 0 user-defined enum/domain/range types, 0 identity columns, 0 extensions installed in `public`, and 0 deferrable constraints.
- Table/column defaults, nullability, unique constraints, primary keys, foreign keys and ON DELETE actions, check constraints, and indexes were read from PostgreSQL catalogs.

## Type and behavior conversions

- PostgreSQL `BIGSERIAL`/sequence-backed primary keys become signed `BIGINT AUTO_INCREMENT`; actual sequence next values are preserved as lower bounds after import.
- `BIGINT`, `INTEGER`, `SMALLINT`, `BOOLEAN`, `VARCHAR(n)`, and `TEXT` are mapped to corresponding MySQL types.
- PostgreSQL `TIMESTAMPTZ` becomes `DATETIME(6)`; exported values are normalized to UTC and the SQL sets the session time zone to UTC. MySQL `DATETIME` does not retain the original timezone metadata.
- PostgreSQL `DATE` remains `DATE`; defaults such as `CURRENT_TIMESTAMP` are emitted as `CURRENT_TIMESTAMP(6)`.
- PostgreSQL `NO ACTION` foreign-key behavior is mapped to MySQL `RESTRICT` where explicit; these are equivalent for the immediate constraints in this schema.
- PostgreSQL text-array CHECK expressions used for enum-like values are translated to `IN (...)`; other simple checks are preserved as MySQL checks.
- The script requires MySQL 8.0.16+ for enforced CHECK constraints and uses InnoDB with utf8mb4.
- The target uses `utf8mb4_0900_bin` to preserve case-sensitive string uniqueness and avoid accent/case folding; ordering and locale-specific comparison rules still differ from the PostgreSQL source collation.

## Validation

- PostgreSQL connection and database identity verified; all source catalog metadata and rows were read inside one read-only REPEATABLE READ snapshot.
- The complete data export was generated from 183 source rows across 13 tables.
- All source foreign keys and CHECK constraints were validated in PostgreSQL and represented in the generated DDL; source relationships were used to order table creation and INSERT statements.
- Static checks confirmed 13 matching `CREATE TABLE` statements, 183 explicit row tuples with the same per-table counts as the live source, the existing admin key/email marker, and 12 sequence-backed `AUTO_INCREMENT` definitions.
- MySQL execution and post-import row-count/foreign-key validation were not performed because MySQL authentication was unavailable. No claim of successful MySQL import is made.
- Password hashes are copied exactly as stored in PostgreSQL; no plaintext passwords are exported.
